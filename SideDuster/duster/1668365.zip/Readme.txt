All configurations are from assignment 1.
Extract and copy the contents of models_to_add.zip to /home/<user_name>/.gazebo/models
Open gazebo, rviz, and sample world with: roslaunch a1_456_referee a1.launch
Run the code with: rosrun a1_456_answer explorer_node_a1_456_python.py
